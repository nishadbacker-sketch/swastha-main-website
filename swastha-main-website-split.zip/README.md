# Swastha Learning Clinic main website — split file package

This website was split from the updated November 27, 2026 Hostinger backup. It preserves the **same** design, CSS order, Malayalam/English translation script, images, and clinic logos. No new design was generated.

- `index.html` — main website structure
- `css/stylesheet-1.css` and `css/stylesheet-2.css` — extracted original CSS
- `js/site-1.js` — original script with the Free Assessment handoff update
- `assets/illustration-1.png` and `assets/illustration-2.jpg` — original embedded images, extracted losslessly
- `robots.txt` and `sitemap.xml` — unchanged SEO files

**Upload ALL files and folders together** to GitHub preserving these paths. Do not upload the former Hostinger `portal/` folder. First verify `https://portal.swasthalearning.com/free-assessment` has the updated handoff code. Main-site update is not published until Hostinger deploys this content. Preserve a backup of the live public_html before deployment.
